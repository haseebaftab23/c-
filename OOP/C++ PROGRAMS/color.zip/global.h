#include <iostream.h>	//cout & cin function
#include <windows.h>	//system functions
#include <stdio.h> 	//main c library

class variable {	//Where variables are stored
public:  	//makes public part of class variable
	int I; 	//makes an integer called I
}; 	//end of class variable
class variable C;	//Assigns class to C