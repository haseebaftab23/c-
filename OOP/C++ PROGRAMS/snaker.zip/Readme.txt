List of files included in this zip

readme.txt           the file you are reading right now

balldraw.h           header file for drawing the balls
fonts.h              header file for my font
grafix.h             header file for my graphics
keyboard.h           header file for the keyboard routines
levels.h             header file for all the levels
menus.h              header file for all things associated with the main menu
optionsm.h           header file to change & set options
plyr.h               header file for i/o with you, the player
wormai.h             header file for the worms ai

snaker.cpp           main part of this game

snaker.exe           the exec

questions/comments/bugs to:   vulcan_lord@hotmail.com
edited levels to:             vulcan_lord@hotmail.com 