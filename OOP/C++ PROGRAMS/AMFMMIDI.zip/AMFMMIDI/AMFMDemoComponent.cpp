/*
  ==============================================================================

This is a simple program I made for the MAT 240D lab to demonstrate AM and FM synthesis in a PortAudio callback using JUCE for the GUI.  
Additionally, I have implemented simple MIDI control input using JUCE's midi functions.  MIDI notes will change
the frequency of the sound playing and MIDI controller knobs/sliders can change the modulation index and modulation frequency.

  ==============================================================================
*/

//[Headers] You can add your own extra header files here...
#include <portaudio.h>
#include <iostream>
//[/Headers]

#include "AMFMDemoComponent.h"


//[MiscUserDefs] You can add your own user definitions and misc code here...

#define NUM_SECONDS   (500)
#define SAMPLE_RATE   (44100)
#define FRAMES_PER_BUFFER  (256)

#ifndef M_PI
#define M_PI  (3.14159265)
#endif

#define TABLE_SIZE   (44100)  // here I just use a large table size instead of interpolating (see interpolation example for that)
#define MOD_TABLE_SIZE (44100)


typedef struct
	{
		float sine[TABLE_SIZE];
		float left_phase;  // don't really need left and right phases for this example, but I just remained consistent with the original PA example
		float right_phase;
		int mod_phase;
		float modFreq;
		float modIndex;
		float amp;
		float scale;
		float freq;
		char message[20];
		int phaseIndex;
	}
	paTestData;


static int AMCallback( const void *inputBuffer, void *outputBuffer,
						  unsigned long framesPerBuffer,
						  const PaStreamCallbackTimeInfo* timeInfo,
						  PaStreamCallbackFlags statusFlags,
						  void *userData )
{
    paTestData *data = (paTestData*)userData;
    float *out = (float*)outputBuffer;
    unsigned long i;
	float mod;
    (void) timeInfo; /* Prevent unused variable warnings. */
    (void) statusFlags;
	(void) inputBuffer;

    for( i=0; i<framesPerBuffer; i++ )
    {

		mod = (float) sin( ((double)data->mod_phase/(double)TABLE_SIZE) * M_PI * 2. ); //mod oscillator

		 //AM
		 *out = data->amp * (float) sin( ((double)data->left_phase/(double)TABLE_SIZE) * M_PI * 2. );
		 *out *= mod; //apply amp modulation
		 *out++;
		 *out = data->amp * (float) sin( ((double)data->right_phase/(double)TABLE_SIZE) * M_PI * 2. );
		 *out *= mod; // apply amp modulation
		 *out++;


		// increment for AM = carrier frequency * table size / samping rate
		data->left_phase += ((data->freq) *(float)TABLE_SIZE/(float)SAMPLE_RATE);
		data->right_phase = data->left_phase;
		if( data->left_phase >= TABLE_SIZE ) data->left_phase -= TABLE_SIZE;
		if( data->right_phase >= TABLE_SIZE ) data->right_phase -= TABLE_SIZE;
			
		// update modulator phase
		data->mod_phase += (int) (data->modFreq*MOD_TABLE_SIZE/SAMPLE_RATE);
        if( data->mod_phase >= MOD_TABLE_SIZE ) data->mod_phase -= MOD_TABLE_SIZE;

	}

	return paContinue;
}

static int FMCallback( const void *inputBuffer, void *outputBuffer,
						  unsigned long framesPerBuffer,
						  const PaStreamCallbackTimeInfo* timeInfo,
						  PaStreamCallbackFlags statusFlags,
						  void *userData )
{
    paTestData *data = (paTestData*)userData;
    float *out = (float*)outputBuffer;
    unsigned long i;
	float mod;
    (void) timeInfo; /* Prevent unused variable warnings. */
    (void) statusFlags;

    for( i=0; i<framesPerBuffer; i++ )
    {

		mod = (float) sin( ((double)data->mod_phase/(double)TABLE_SIZE) * M_PI * 2. ); //mod oscillator
		mod *= data->modIndex * data->modFreq; //scale the freq deviation by the modulation index

		// FM
		 *out++ = data->amp * (float) sin( ((double)data->left_phase/(double)TABLE_SIZE) * M_PI * 2. );
		 *out++ = data->amp * (float) sin( ((double)data->right_phase/(double)TABLE_SIZE) * M_PI * 2. );

		// increment for FM =(carrier freq + mod freq) * table size / samping rate
        data->left_phase += (int) ((data->freq + mod) *TABLE_SIZE/SAMPLE_RATE);
        if( data->left_phase >= TABLE_SIZE ) data->left_phase -= TABLE_SIZE;
        data->right_phase += (int) ((data->freq + mod)*TABLE_SIZE/SAMPLE_RATE);
        if( data->right_phase >= TABLE_SIZE ) data->right_phase -= TABLE_SIZE;

		// update modulator phase
		data->mod_phase += (int) (data->modFreq*MOD_TABLE_SIZE/SAMPLE_RATE);
        if( data->mod_phase >= MOD_TABLE_SIZE ) data->mod_phase -= MOD_TABLE_SIZE;

    }

    return paContinue;
}


//This routine is called by portaudio when playback is done.
static void StreamFinished( void* userData )
{
	paTestData *data = (paTestData *) userData;
	printf( "Stream Completed: %s\n", data->message );
}


PaStreamParameters outputParameters;
PaStream *stream;
PaError err;
paTestData data;


// this is my setup funtion to initialize the wavertable and port audio params
//this will be called from my Juce component's constructor
static void portAudioSetup(void){
						  
	for(int i=0; i<TABLE_SIZE; i++ ){
		
		data.sine[i] = (float) sin( ((double)i/(double)TABLE_SIZE) * M_PI * 2. );  // initialize sine table
	
	}
						  
						  
	data.amp = 1; //initialize amplitude
	data.freq = 440;
    data.left_phase = data.right_phase = 0;
	data.mod_phase = 0;

	Pa_Initialize();

	outputParameters.device = Pa_GetDefaultOutputDevice(); /* default output device */
	outputParameters.channelCount = 2;       /* stereo output */
	outputParameters.sampleFormat = paFloat32; /* 32 bit floating point output */
	outputParameters.suggestedLatency = Pa_GetDeviceInfo( outputParameters.device )->defaultLowOutputLatency;
	outputParameters.hostApiSpecificStreamInfo = NULL;
		
}

//[/MiscUserDefs]

//==============================================================================
AMFMDemoComponent::AMFMDemoComponent ()
    : playButton (0),
      stopButton (0),
      ampSlider (0),
      freqSlider (0),
      ampLabel (0),
      freqLabel (0),
      modFreqSlider (0),
      freqLabel2 (0),
      modInxSlider (0),
      freqLabel3 (0),
      synthTypeBox (0)
{
    addAndMakeVisible (playButton = new TextButton (T("play button")));
    playButton->setButtonText (T("Play"));
    playButton->addButtonListener (this);

    addAndMakeVisible (stopButton = new TextButton (T("stop button")));
    stopButton->setButtonText (T("Stop"));
    stopButton->addButtonListener (this);

    addAndMakeVisible (ampSlider = new Slider (T("amp slider")));
    ampSlider->setRange (0, 1, 0.01);
    ampSlider->setSliderStyle (Slider::LinearVertical);
    ampSlider->setTextBoxStyle (Slider::TextBoxBelow, false, 80, 20);
    ampSlider->addListener (this);

    addAndMakeVisible (freqSlider = new Slider (T("freq slider")));
    freqSlider->setRange (0, 1000, 1);
    freqSlider->setSliderStyle (Slider::LinearVertical);
    freqSlider->setTextBoxStyle (Slider::TextBoxBelow, false, 80, 20);
    freqSlider->addListener (this);

    addAndMakeVisible (ampLabel = new Label (T("amp label"),
                                             T("Amplitude")));
    ampLabel->setFont (Font (15.0000f, Font::plain));
    ampLabel->setJustificationType (Justification::centredLeft);
    ampLabel->setEditable (false, false, false);
    ampLabel->setColour (TextEditor::textColourId, Colours::black);
    ampLabel->setColour (TextEditor::backgroundColourId, Colour (0x0));

    addAndMakeVisible (freqLabel = new Label (T("freq label"),
                                              T("Carrier Freq")));
    freqLabel->setFont (Font (15.0000f, Font::plain));
    freqLabel->setJustificationType (Justification::centredLeft);
    freqLabel->setEditable (false, false, false);
    freqLabel->setColour (TextEditor::textColourId, Colours::black);
    freqLabel->setColour (TextEditor::backgroundColourId, Colour (0x0));

    addAndMakeVisible (modFreqSlider = new Slider (T("freq slider")));
    modFreqSlider->setRange (0, 1000, 1);
    modFreqSlider->setSliderStyle (Slider::LinearVertical);
    modFreqSlider->setTextBoxStyle (Slider::TextBoxBelow, false, 80, 20);
    modFreqSlider->addListener (this);

    addAndMakeVisible (freqLabel2 = new Label (T("freq label"),
                                               T("Mod Freq")));
    freqLabel2->setFont (Font (15.0000f, Font::plain));
    freqLabel2->setJustificationType (Justification::centredLeft);
    freqLabel2->setEditable (false, false, false);
    freqLabel2->setColour (TextEditor::textColourId, Colours::black);
    freqLabel2->setColour (TextEditor::backgroundColourId, Colour (0x0));

    addAndMakeVisible (modInxSlider = new Slider (T("freq slider")));
    modInxSlider->setRange (0, 30, 0.1);
    modInxSlider->setSliderStyle (Slider::LinearVertical);
    modInxSlider->setTextBoxStyle (Slider::TextBoxBelow, false, 80, 20);
    modInxSlider->addListener (this);

    addAndMakeVisible (freqLabel3 = new Label (T("freq label"),
                                               T("Mod Index")));
    freqLabel3->setFont (Font (15.0000f, Font::plain));
    freqLabel3->setJustificationType (Justification::centredLeft);
    freqLabel3->setEditable (false, false, false);
    freqLabel3->setColour (TextEditor::textColourId, Colours::black);
    freqLabel3->setColour (TextEditor::backgroundColourId, Colour (0x0));

    addAndMakeVisible (synthTypeBox = new ComboBox (T("new combo box")));
    synthTypeBox->setEditableText (false);
    synthTypeBox->setJustificationType (Justification::centredLeft);
    synthTypeBox->setTextWhenNothingSelected (String::empty);
    synthTypeBox->setTextWhenNoChoicesAvailable (T("(no choices)"));
    synthTypeBox->addItem (T("AM"), 1);
    synthTypeBox->addItem (T("FM"), 2);
    synthTypeBox->addListener (this);


    //[UserPreSize]
    //[/UserPreSize]

    setSize (500, 500);

    //[Constructor] You can add your own custom stuff here..

	portAudioSetup(); //initialize wavetable and port audio params

	ampSlider->setValue(0.5);  //set amplitude to 0.5
	synthTypeBox->setSelectedId(1); // Choose AM synthesis (item 1) by default
	freqSlider->setValue(220);
	modFreqSlider->setValue(5);
	
	startTimer(10);  // starts timer that checks for MIDI notes every 10ms.  Should probably use a JUCE change broadcaster/action listener instead of a timer to check for midi

    //[/Constructor]
}

AMFMDemoComponent::~AMFMDemoComponent()
{
    //[Destructor_pre]. You can add your own custom destruction code here..
    //[/Destructor_pre]

    deleteAndZero (playButton);
    deleteAndZero (stopButton);
    deleteAndZero (ampSlider);
    deleteAndZero (freqSlider);
    deleteAndZero (ampLabel);
    deleteAndZero (freqLabel);
    deleteAndZero (modFreqSlider);
    deleteAndZero (freqLabel2);
    deleteAndZero (modInxSlider);
    deleteAndZero (freqLabel3);
    deleteAndZero (synthTypeBox);

    //[Destructor]. You can add your own custom destruction code here..

	Pa_CloseStream( stream );
	Pa_Terminate();

    //[/Destructor]
}

//==============================================================================
void AMFMDemoComponent::paint (Graphics& g)
{
    //[UserPrePaint] Add your own custom painting code here..
    //[/UserPrePaint]

    g.fillAll (Colour (0xff00a6f7));

    //[UserPaint] Add your own custom painting code here..
    //[/UserPaint]
}

void AMFMDemoComponent::resized()
{
    playButton->setBounds (48, 344, 71, 24);
    stopButton->setBounds (168, 344, 71, 24);
    ampSlider->setBounds (8, 48, 80, 256);
    freqSlider->setBounds (112, 48, 72, 256);
    ampLabel->setBounds (8, 8, 72, 24);
    freqLabel->setBounds (120, 8, 72, 24);
    modFreqSlider->setBounds (216, 48, 72, 256);
    freqLabel2->setBounds (216, 8, 72, 24);
    modInxSlider->setBounds (320, 48, 72, 256);
    freqLabel3->setBounds (312, 8, 72, 24);
    synthTypeBox->setBounds (280, 344, 88, 24);
    //[UserResized] Add your own custom resize handling here..
    //[/UserResized]
}

void AMFMDemoComponent::buttonClicked (Button* buttonThatWasClicked)
{
    //[UserbuttonClicked_Pre]
    //[/UserbuttonClicked_Pre]

    if (buttonThatWasClicked == playButton)
    {
        //[UserButtonCode_playButton] -- add your button handler code here..

		if(synthTypeBox->getSelectedId() == 1){  // start AM stream

			Pa_OpenStream(
							&stream,
							NULL, /* no input */
							&outputParameters,
							SAMPLE_RATE,
							FRAMES_PER_BUFFER,
							paClipOff,      /* we won't output out of range samples so don't bother clipping them */
							AMCallback,
							&data );
		}
		if(synthTypeBox->getSelectedId() == 2){  // start FM stream

			Pa_OpenStream(
						  &stream,
						  NULL, /* no input */
						  &outputParameters,
						  SAMPLE_RATE,
						  FRAMES_PER_BUFFER,
						  paClipOff,      /* we won't output out of range samples so don't bother clipping them */
						  FMCallback,
						  &data );
		}

		Pa_SetStreamFinishedCallback( stream, &StreamFinished );

		Pa_StartStream( stream );

        //[/UserButtonCode_playButton]
    }
    else if (buttonThatWasClicked == stopButton)
    {
        //[UserButtonCode_stopButton] -- add your button handler code here..
		Pa_StopStream( stream );
		Pa_CloseStream( stream );
        //[/UserButtonCode_stopButton]
    }

    //[UserbuttonClicked_Post]
    //[/UserbuttonClicked_Post]
}

void AMFMDemoComponent::sliderValueChanged (Slider* sliderThatWasMoved)
{
    //[UsersliderValueChanged_Pre]
    //[/UsersliderValueChanged_Pre]

    if (sliderThatWasMoved == ampSlider)
    {
        //[UserSliderCode_ampSlider] -- add your slider handling code here..

		data.amp = (float) ampSlider->getValue();

        //[/UserSliderCode_ampSlider]
    }
    else if (sliderThatWasMoved == freqSlider)
    {
        //[UserSliderCode_freqSlider] -- add your slider handling code here..

		data.freq = (float) freqSlider->getValue();

        //[/UserSliderCode_freqSlider]
    }
    else if (sliderThatWasMoved == modFreqSlider)
    {
        //[UserSliderCode_modFreqSlider] -- add your slider handling code here..

		data.modFreq = modFreqSlider->getValue();

        //[/UserSliderCode_modFreqSlider]
    }
    else if (sliderThatWasMoved == modInxSlider)
    {
        //[UserSliderCode_modInxSlider] -- add your slider handling code here..

		data.modIndex = modInxSlider->getValue();

        //[/UserSliderCode_modInxSlider]
    }

    //[UsersliderValueChanged_Post]
    //[/UsersliderValueChanged_Post]
}

void AMFMDemoComponent::comboBoxChanged (ComboBox* comboBoxThatHasChanged)
{
    //[UsercomboBoxChanged_Pre]
    //[/UsercomboBoxChanged_Pre]

    if (comboBoxThatHasChanged == synthTypeBox)
    {
        //[UserComboBoxCode_synthTypeBox] -- add your combo box handling code here..
        //[/UserComboBoxCode_synthTypeBox]
    }

    //[UsercomboBoxChanged_Post]
    //[/UsercomboBoxChanged_Post]
}



//[MiscUserCode] You can add your own definitions of your custom methods or any other code here...

void AMFMDemoComponent::timerCallback(){
	
	if(myMidi.isMidiNoteOn()){  //is there a new midi note on message?
		
		//std::cout << "midi note number: " << myMidi.getCurrentMidiNote() << " \n";
		
		freqSlider->setValue(myMidi.getCurrentMidiNoteHz());  // set freq to that of the current midi note
		
		myMidi.setMidiNoteOff();  // turn off our midi noteOn variable so this routine doesn't get called on the next interval
	}
	
	if(myMidi.getControlChange()){
		
		//output the current controller number, use this to check the mapping of your midi controller and then replace numbers 12-14 below with your controller's numbers
		// it would also be a good idea to implement a learning switch.  when learn is on read the current controller and then map it to any control on the GUI
		std::cout << "midi control number: " << myMidi.getCurrentControlNum() << " \n"; 
		
		//MIDI controllers only output values 0-127 so we have to map these to the appropriate ranges
		if(myMidi.getCurrentControlNum() == 12){
			ampSlider->setValue(myMidi.getCurrentControlVal()/127.);
		}
		if(myMidi.getCurrentControlNum() == 14){
			modInxSlider->setValue(myMidi.getCurrentControlVal()/5.);
		}
		if(myMidi.getCurrentControlNum() == 13){
			modFreqSlider->setValue(myMidi.getCurrentControlVal()*7.87);
		}
		myMidi.setControlChangeOff();
	}
	
}

//[/MiscUserCode]


//==============================================================================
#if 0
/*  -- Jucer information section --

    This is where the Jucer puts all of its metadata, so don't change anything in here!

BEGIN_JUCER_METADATA

<JUCER_COMPONENT documentType="Component" className="AMFMDemoComponent" componentName=""
                 parentClasses="public Component" constructorParams="" variableInitialisers=""
                 snapPixels="8" snapActive="1" snapShown="1" overlayOpacity="0.330000013"
                 fixedSize="0" initialWidth="500" initialHeight="500">
  <BACKGROUND backgroundColour="ff00a6f7"/>
  <TEXTBUTTON name="play button" id="5584f9d11b0ba42a" memberName="playButton"
              virtualName="" explicitFocusOrder="0" pos="48 344 71 24" buttonText="Play"
              connectedEdges="0" needsCallback="1" radioGroupId="0"/>
  <TEXTBUTTON name="stop button" id="942b7c476b966eec" memberName="stopButton"
              virtualName="" explicitFocusOrder="0" pos="168 344 71 24" buttonText="Stop"
              connectedEdges="0" needsCallback="1" radioGroupId="0"/>
  <SLIDER name="amp slider" id="c0e0ee9970edaebc" memberName="ampSlider"
          virtualName="" explicitFocusOrder="0" pos="8 48 80 256" min="0"
          max="1" int="0.01" style="LinearVertical" textBoxPos="TextBoxBelow"
          textBoxEditable="1" textBoxWidth="80" textBoxHeight="20" skewFactor="1"/>
  <SLIDER name="freq slider" id="59bd6127c7bcfef0" memberName="freqSlider"
          virtualName="" explicitFocusOrder="0" pos="112 48 72 256" min="0"
          max="1000" int="1" style="LinearVertical" textBoxPos="TextBoxBelow"
          textBoxEditable="1" textBoxWidth="80" textBoxHeight="20" skewFactor="1"/>
  <LABEL name="amp label" id="a029e465b901bbf6" memberName="ampLabel"
         virtualName="" explicitFocusOrder="0" pos="8 8 72 24" edTextCol="ff000000"
         edBkgCol="0" labelText="Amplitude" editableSingleClick="0" editableDoubleClick="0"
         focusDiscardsChanges="0" fontname="Default font" fontsize="15"
         bold="0" italic="0" justification="33"/>
  <LABEL name="freq label" id="cfecd6621a7a4527" memberName="freqLabel"
         virtualName="" explicitFocusOrder="0" pos="120 8 72 24" edTextCol="ff000000"
         edBkgCol="0" labelText="Carrier Freq" editableSingleClick="0"
         editableDoubleClick="0" focusDiscardsChanges="0" fontname="Default font"
         fontsize="15" bold="0" italic="0" justification="33"/>
  <SLIDER name="freq slider" id="d4732bc196578264" memberName="modFreqSlider"
          virtualName="" explicitFocusOrder="0" pos="216 48 72 256" min="0"
          max="1000" int="1" style="LinearVertical" textBoxPos="TextBoxBelow"
          textBoxEditable="1" textBoxWidth="80" textBoxHeight="20" skewFactor="1"/>
  <LABEL name="freq label" id="f8bdbbf4c5953fe0" memberName="freqLabel2"
         virtualName="" explicitFocusOrder="0" pos="216 8 72 24" edTextCol="ff000000"
         edBkgCol="0" labelText="Mod Freq" editableSingleClick="0" editableDoubleClick="0"
         focusDiscardsChanges="0" fontname="Default font" fontsize="15"
         bold="0" italic="0" justification="33"/>
  <SLIDER name="freq slider" id="ff3c8b96d45a6085" memberName="modInxSlider"
          virtualName="" explicitFocusOrder="0" pos="320 48 72 256" min="0"
          max="30" int="0.1" style="LinearVertical" textBoxPos="TextBoxBelow"
          textBoxEditable="1" textBoxWidth="80" textBoxHeight="20" skewFactor="1"/>
  <LABEL name="freq label" id="146446876883a18d" memberName="freqLabel3"
         virtualName="" explicitFocusOrder="0" pos="312 8 72 24" edTextCol="ff000000"
         edBkgCol="0" labelText="Mod Index" editableSingleClick="0" editableDoubleClick="0"
         focusDiscardsChanges="0" fontname="Default font" fontsize="15"
         bold="0" italic="0" justification="33"/>
  <COMBOBOX name="new combo box" id="f6887b36000f3f20" memberName="synthTypeBox"
            virtualName="" explicitFocusOrder="0" pos="280 344 88 24" editable="0"
            layout="33" items="AM&#10;FM" textWhenNonSelected="" textWhenNoItems="(no choices)"/>
</JUCER_COMPONENT>

END_JUCER_METADATA
*/
#endif
