
#include "MidiMessageManager.h"


MidiMessageManager::MidiMessageManager() : midiNote(0), velocity(0)

{
	
	controlChange = false;
	midiInput = MidiInput::openDevice(MidiInput::getDefaultDeviceIndex(),this);
	//std::cout<< "midi dev index = " << MidiInput::getDefaultDeviceIndex();
	if(midiInput) midiInput->start(); // if there is a midi input then start it
}

MidiMessageManager::~MidiMessageManager()
{
	midiInput->stop();
}

int MidiMessageManager::getCurrentMidiNote()
{
	return midiNote;
}
float MidiMessageManager::getCurrentMidiNoteHz()
{
	return midiNoteHz;
}
bool MidiMessageManager::isMidiNoteOn()
{
	return midiNoteOn;
}
int MidiMessageManager::getCurrentControlNum()
{
	return controlNum;
}
int MidiMessageManager::getCurrentControlVal()
{
	return controlVal;
}
bool MidiMessageManager::getControlChange()
{
	return controlChange;
}
void MidiMessageManager::setControlChangeOff()
{
	controlChange = false;
}
void MidiMessageManager::setMidiNoteOff()
{
	midiNoteOn = false;
}
int MidiMessageManager::getCurrentMidiVelocity()
{
	return velocity;
}



void MidiMessageManager::handleIncomingMidiMessage (MidiInput*, const MidiMessage& message)
{
	
	if(message.isNoteOn())
	{
		midiNoteOn = true;  //switch our note on trigger to true
		midiNote = message.getNoteNumber();
		midiNoteHz = message.getMidiNoteInHertz(midiNote);
		velocity = (int)(message.getVelocity());
	}
	
	if(message.isController())
	{
		controlChange = true;
		controlNum = message.getControllerNumber();
		controlVal = message.getControllerValue();
	}

}
