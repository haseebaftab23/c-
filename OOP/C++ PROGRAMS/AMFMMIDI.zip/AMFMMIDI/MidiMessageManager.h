// Thanks to Phillip Popp for the original version of this!


#ifndef MIDIMESSAGEMANAGER_H
#define MIDIMESSAGEMANAGER_H

#include <juce_amalgamated.h>
#include <iostream>

class MidiMessageManager : public MidiInputCallback	
{
public:
	
    MidiMessageManager();
    ~MidiMessageManager();
	
	int getCurrentMidiNote();
	float getCurrentMidiNoteHz();
	int getCurrentControlNum();
	int getCurrentControlVal();
	bool isMidiNoteOn();
	bool getControlChange();
	void setControlChangeOff();
	void setMidiNoteOff();
	int getCurrentMidiVelocity();
    
	//required of any superclass of MidiInputCallback.  This is called everytime a midi message is played
	void handleIncomingMidiMessage (MidiInput* source, const MidiMessage& message);
	
private:
	
	MidiInput *midiInput;
	
	int midiNote;
	float midiNoteHz;
	bool midiNoteOn; 
	int controlNum;
	int controlVal;
	bool controlChange;
	int velocity;
	
	// (prevent copy constructor and operator= being generated..)
    MidiMessageManager (const MidiMessageManager&);
    const MidiMessageCollector& operator= (const MidiMessageManager&);
};

#endif