/*
  ==============================================================================

  This is an automatically generated file created by the Jucer!

  Creation date:  16 Oct 2009 10:41:13 am

  Be careful when adding custom code to these files, as only the code within
  the "//[xyz]" and "//[/xyz]" sections will be retained when the file is loaded
  and re-saved.

  Jucer version: 1.11

  ------------------------------------------------------------------------------

  The Jucer is part of the JUCE library - "Jules' Utility Class Extensions"
  Copyright 2004-6 by Raw Material Software ltd.

  ==============================================================================
*/

#ifndef __JUCER_HEADER_AMFMDEMOCOMPONENT_PORTAUDIODEMOCOMPONENT_787AE30B__
#define __JUCER_HEADER_AMFMDEMOCOMPONENT_PORTAUDIODEMOCOMPONENT_787AE30B__

//[Headers]     -- You can add your own extra header files here --
#include <juce_amalgamated.h>
#include "MidiMessageManager.h"
//[/Headers]


//==============================================================================
/**
                                                                    //[Comments]
    An auto-generated component, created by the Jucer.

    Describe your class and how it works here!
                                                                    //[/Comments]
*/



class AMFMDemoComponent  : public Component,
                           public ButtonListener,
                           public SliderListener,
                           public ComboBoxListener,
						   public Timer
{
public:
    //==============================================================================
    AMFMDemoComponent ();
    ~AMFMDemoComponent();

    //==============================================================================
    //[UserMethods]     -- You can add your own custom methods in this section.

	void timerCallback();
    //[/UserMethods]

    void paint (Graphics& g);
    void resized();
    void buttonClicked (Button* buttonThatWasClicked);
    void sliderValueChanged (Slider* sliderThatWasMoved);
    void comboBoxChanged (ComboBox* comboBoxThatHasChanged);


    //==============================================================================
    juce_UseDebuggingNewOperator

private:
    //[UserVariables]   -- You can add your own custom variables in this section.

	MidiMessageManager myMidi;
	
    //[/UserVariables]

    //==============================================================================
    TextButton* playButton;
    TextButton* stopButton;
    Slider* ampSlider;
    Slider* freqSlider;
    Label* ampLabel;
    Label* freqLabel;
    Slider* modFreqSlider;
    Label* freqLabel2;
    Slider* modInxSlider;
    Label* freqLabel3;
    ComboBox* synthTypeBox;

    //==============================================================================
    // (prevent copy constructor and operator= being generated..)
    AMFMDemoComponent (const AMFMDemoComponent&);
    const AMFMDemoComponent& operator= (const AMFMDemoComponent&);
};


#endif   // __JUCER_HEADER_AMFMDEMOCOMPONENT_PORTAUDIODEMOCOMPONENT_787AE30B__
