// MP3Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "MP3.h"
#include "MP3Dlg.h"
#include "vfw.h"
#include "Aboute.h"
#include "windows.h"
#include <ctype.h>
#include <direct.h>

#include <mmsystem.h>
#include "dbt.h"
#include "winuser.h"

#include "playlist1.h"
#include "Digitalv.h"
#include <afxctl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMP3Dlg dialog

CMP3Dlg::CMP3Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMP3Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMP3Dlg)
	m_l = 0;
	TotalTime = 0.0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	flag=0;
	FullScreen=0;
	timer=0;
	mute=0;
	m1=0;
	repeat=1;
	m_Index=0;
	m=1;
	e=1;
	t=50;
	SongNo=0;
	m_Volume=400;
	m_length=NULL;
	OldFileName2=NewFileName2="";
	m_Video = NULL;
	 lst= NULL;
	Files[0]="";
	Index=0;
	
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
//	LoadAccelerators(this->GetSafeHwnd(),IDR_MAINFRAME);


}

void CMP3Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMP3Dlg)
	DDX_Control(pDX, IDC_SLIDER1, m_Seek);
	DDX_Control(pDX, IDC_Volume, m_SVolume);
	DDX_Control(pDX, IDC_Screen, m_screen);
	DDX_Control(pDX, IDC_Mute, m_mute);
	DDX_Text(pDX, IDC_time, m_l);
	DDX_Text(pDX, IDC_time2, TotalTime);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMP3Dlg, CDialog)
	//{{AFX_MSG_MAP(CMP3Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_pause, Onpause)
	ON_BN_CLICKED(IDC_Mute, OnMute)
	ON_COMMAND(ID_Open, OnOpen)
	ON_COMMAND(ID_Play, OnPlay)
	ON_COMMAND(ID_Stop, OnStop)
	ON_UPDATE_COMMAND_UI(ID_Open, OnUpdateOpen)
	ON_UPDATE_COMMAND_UI(ID_Play, OnUpdatePlay)
	ON_COMMAND(ID_Maximize, OnMaximize)
	ON_COMMAND(ID_Save, OnSave)
	ON_COMMAND(ID_Minimize, OnMinimize)
	ON_COMMAND(ID_VIEW__10, OnView10)
	ON_COMMAND(ID_VIEW__20, OnView20)
	ON_COMMAND(ID_VIEW__40, OnView40)
	ON_COMMAND(ID_VIEW_ZOOM_70, OnViewZoom70)
	ON_COMMAND(ID_VIEW_ZOOM_150, OnViewZoom150)
	ON_COMMAND(ID_TOOLS_SPEED_DOUBLE, OnToolsSpeedDouble)
	ON_COMMAND(ID_TOOLS_SPEED_HALF, OnToolsSpeedHalf)
	ON_COMMAND(ID_TOOLS_SPEED_INCREASE, OnToolsSpeedIncrease)
	ON_COMMAND(ID_TOOLS_SPEED_DECREASE, OnToolsSpeedDecrease)
	ON_COMMAND(ID_TOOLS_SPEED_NORMAL, OnToolsSpeedNormal)
	ON_COMMAND(ID_TOOLS_REPEAT, OnToolsRepeat)
	ON_COMMAND(ID_TOOLS_VOLUME_UP, OnToolsVolumeUp)
	ON_COMMAND(ID_TOOLS_VOLUME_MUTE, OnToolsVolumeMute)
	ON_COMMAND(ID_TOOLS_VOLUME_DOWN, OnToolsVolumeDown)
	ON_WM_CLOSE()
	ON_WM_CHAR()
	ON_COMMAND(ID_Repeat, OnRepeat)
	ON_COMMAND(ID_FILE_EJECT, OnFileEject)
	ON_COMMAND(ID_FILE_INSERT, OnFileInsert)
	ON_COMMAND(ID_FILE_EXIT, OnFileExit)
	ON_COMMAND(ID_ABOUT_ABOUTMEDIAPLAYER, OnAboutAboutmediaplayer)
	ON_COMMAND(ID_TOOLS_VOLUME_ADVANCED, OnToolsVolumeAdvanced)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_Volume, OnCustomdrawVolume)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER1, OnCustomdrawSlider1)
	ON_WM_TIMER()
	ON_COMMAND(ID_PLAY_NEXT, OnPlayNext)
	ON_COMMAND(ID_PLAY_PREVIUS, OnPlayPrevius)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER1, OnReleasedcaptureSlider1)
	ON_COMMAND(ID_VIEW_FULLSCREEN, OnViewFullscreen)
	ON_BN_CLICKED(IDC_Play2, OnPause)
	ON_BN_CLICKED(IDC_eject, OnEject)
	ON_BN_CLICKED(IDC_fullscreen, Onfullscreen)
	ON_BN_CLICKED(IDC_Previus, OnPrevius)
	ON_BN_CLICKED(IDC_Next, OnNext)
	ON_BN_CLICKED(IDC_PlayList, OnPlayList)
	ON_BN_CLICKED(IDC_SpeedIncrease, OnSpeedIncrease)
	ON_BN_CLICKED(IDC_SpeedSlow, OnSpeedSlow)
	ON_BN_CLICKED(IDC_Close, OnExit)
	ON_BN_CLICKED(IDC_Forward, OnForward)
	ON_COMMAND(ID_CLOSE, OnFileClose)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_Play, OnPlay)
	ON_BN_CLICKED(IDC_Play4, OnOpen)
	ON_BN_CLICKED(IDC_Repeat, OnRepeat)
	ON_BN_CLICKED(IDC_FileClose, OnFileClose)
	ON_BN_CLICKED(IDC_Back, OnBack)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMP3Dlg message handlers

BOOL CMP3Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect r;
	GetClientRect(r);
	m_rgn.CreateEllipticRgn(04,04,r.Width(),r.Height());
	SetWindowRgn(m_rgn,TRUE);

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
//	CreateToolBar();
	// TODO: Add extra initialization here
	fFile = false;
	if(m_Video!=NULL)
	ptr->UpdateWindow();

	VERIFY(m_bmp1.AutoLoad(IDC_Play,this));
	VERIFY(m_bmp2.AutoLoad(IDC_Next,this));
	VERIFY(m_bmp3.AutoLoad(IDC_Previus,this));
	VERIFY(m_bmp4.AutoLoad(IDC_Play4,this));
	VERIFY(m_bmp5.AutoLoad(IDC_eject,this));
	VERIFY(m_bmp6.AutoLoad(IDC_Back,this));
	VERIFY(m_bmp7.AutoLoad(IDC_Repeat,this));
	VERIFY(m_bmp8.AutoLoad(IDC_FileClose,this));
	VERIFY(m_bmp9.AutoLoad(IDC_fullscreen,this));
	VERIFY(m_bmp10.AutoLoad(IDC_SpeedSlow,this));
	VERIFY(m_bmp11.AutoLoad(IDC_SpeedIncrease,this));
	VERIFY(m_bmp12.AutoLoad(IDC_Close,this));
	VERIFY(m_bmp13.AutoLoad(IDC_PlayList,this));
	VERIFY(m_bmp14.AutoLoad(IDC_Play2,this));
	VERIFY(m_bmp15.AutoLoad(IDC_Forward,this));
	SetWindowText( "                                           Tahir" );
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMP3Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
	



}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMP3Dlg::OnQueryDragIcon()
{

	return (HCURSOR) m_hIcon;
}



void CMP3Dlg::Onpause() 
{
	// TODO: Add your control notification handler code here
	if(flag==0)
	{
		flag=1;
		MCIWndResume(m_Video);
		
	}
	else
	{
		flag=0;
		MCIWndPause(m_Video);
		
	}

}

void CMP3Dlg::OnStop() 
{
	// TODO: Add your control notification handler code here
	MCIWndSeek(m_Video,MCIWND_START);
//	m_Play.SetWindowText("Play");
	flag=0;
}


void CMP3Dlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar *pScrollBar)
{

/*	if(m_mute.GetCheck()==1){
	
	t=reinterpret_cast<CSliderCtrl *>(pScrollBar)->GetPos();
	MCIWndSetVolume(m_Video, t*10 );

	}*/
}

void CMP3Dlg::OnMute() 
{
	// TODO: Add your control notification handler code here
		if(m_mute.GetCheck()==0){
	MCIWndSetVolume(m_Video, 0 );
	mute=1;
	}
	else
	{
		MCIWndSetVolume(m_Video, m_Volume );
		mute=0;
	}


}

void CMP3Dlg::OnOpen() 
{
	// TODO: Add your command handler code here
/*	CString str;
	CFileDialog avi(TRUE,NULL,NULL,OFN_HIDEREADONLY,"All Files(*.*)|*.*|MP3 Files (*.mp3)|*.mp3|AVI Files(*.avi)|*.avi|");
	if(avi.DoModal() == IDOK)
	{
		if(e==0)
		{
			OnFileClose();
			m_Path = avi.GetPathName();
			//OldFilename=SetExtention(m_Path);
			CreateWindowplay(m_Path);
		}
		else 
		{
			m_Path = avi.GetPathName();
			//OldFilename=SetExtention(m_Path);
			CreateWindowplay(m_Path);
		}
	}
	*/
	POSITION currPos;
	CFileDialog avi(TRUE,NULL,NULL,OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,"All Files(*.*)|*.*|MP3 Files (*.mp3)|*.mp3|AVI Files(*.avi)|*.avi|");
	if(avi.DoModal() == IDOK)
	{
		currPos = avi.GetStartPosition();
		while(currPos != NULL)
		{
			m_Path = avi.GetNextPathName(currPos);
			Files[Index]=m_Path;
			Index++;
		
		}
		if(e==0)
		{
		OnFileClose();
		CreateWindowplay(m_Path);
		}
		else
		CreateWindowplay(m_Path);
	}
	
}

void CMP3Dlg::OnPlay() 
{
	// TODO: Add your command handler code here
if(flag==0)
	{
		MCIWndPlay(m_Video);
		flag=1;
	}
	else
	{
		MCIWndPause(m_Video);
		flag=0;
	} 
	if(m_mute.GetCheck()==1){
		int a;
		a=m_SVolume.GetPos();
	MCIWndSetVolume(m_Video, a/3);
	
	m=0;
	}
	else
	MCIWndSetVolume(m_Video, 0);
}

void CMP3Dlg::OnFileClose() 
{
	// TODO: Add your command handler code here
	MCIWndStop(m_Video);
	if(m_Video !=NULL)
	{
		KillTimer(0);
		MCIWndDestroy(m_Video);
		m_Video=NULL;
		m_Seek.SetPos(0);
	//	if(lst->rFlag==1)
	}/*	{
	m_Path=lst->OldFileName;
	OldFilename=NewFileName2;
	lst->rFlag=0;
		}
	//	RestoreExtention(OldFilename);
		m_Video=NULL;
	}

	m_length=0;
	*/
	flag=0;
	m_l=0;
	TotalTime=0;
	SeekPos=0;
	FullScreen=0;
	UpdateData(FALSE);
	//fFile = false;
//	GetDlgItem(IDC_brouwse)->EnableWindow(TRUE);
//	m_Play.SetWindowText("Play");
//	UpdateData(FALSE);
//	e=1;
}

void CMP3Dlg::OnUpdateOpen(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
//	pCmdUI->Enable(e);
}

void CMP3Dlg::OnUpdatePlay(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CMP3Dlg::OnMaximize() 
{
	// TODO: Add your command handler code here
//	MCIWndChangeStyles(m_Video,MCIWNDF_NOTIFYPOS |MCIWNDF_NOTIFYMEDIA ,WS_MAXIMIZE);
//	MCIWndSetZoom(m_Video,400);
//	ShowWindow(m_Video,SW_MAXIMIZE);
/*
	MCI_RECORD_PARMS RecParms;
	char buff[101];
	int chk;
	CString str;

	MCIWndGetDevice(m_Video, buff, 100);

//	chk = mciSendCommand(mciGetDeviceID(buff), MCI_RECORD, MCI_TEST, (unsigned long)&RecParms);

	wsprintf(
	chk = mciSendString("save digitalvideo c:\test.mpg", NULL, NULL, NULL);

	str.Format("chk = %d", chk);
	AfxMessageBox(str);
//	MCI_Record(m_Video);

*/
}

void CMP3Dlg::OnSave() 
{
	// TODO: Add your command handler code here

	MCIWndSaveDialog(m_Video);

}

void CMP3Dlg::OnMinimize() 
{
	// TODO: Add your command handler code here
	MCIWndSetZoom(m_Video,100);
}

void CMP3Dlg::OnView10() 
{
	// TODO: Add your command handler code here
	MCIWndSetZoom(m_Video,10);
}

void CMP3Dlg::OnView20() 
{
	// TODO: Add your command handler code here
	MCIWndSetZoom(m_Video,20);
}

void CMP3Dlg::OnView40() 
{
	// TODO: Add your command handler code here
	MCIWndSetZoom(m_Video,40);
}

void CMP3Dlg::OnViewZoom70() 
{
	// TODO: Add your command handler code here
	MCIWndSetZoom(m_Video,70);
}

void CMP3Dlg::OnViewZoom150() 
{
	// TODO: Add your command handler code here
	MCIWndSetZoom(m_Video,150);
}

void CMP3Dlg::OnToolsSpeedDouble() 
{
	// TODO: Add your command handler code here
	MCIWndSetSpeed(m_Video,2000);
	m_Volume=2000;
}

void CMP3Dlg::OnToolsSpeedHalf() 
{
	// TODO: Add your command handler code here
	MCIWndSetSpeed(m_Video,500);
	m_Volume=500;
}

void CMP3Dlg::OnToolsSpeedIncrease() 
{
	// TODO: Add your command handler code here
	int a;
	a=MCIWndGetSpeed(m_Video);
	a=a+200;
	if(a<2000)
	MCIWndSetSpeed(m_Video,a);
}

void CMP3Dlg::OnToolsSpeedDecrease() 
{
	// TODO: Add your command handler code here
	int a;
	a=MCIWndGetSpeed(m_Video);
	a=a-200;
	if(a>0)
	MCIWndSetSpeed(m_Video,a);
}

void CMP3Dlg::OnToolsSpeedNormal() 
{
	// TODO: Add your command handler code here
	MCIWndSetSpeed(m_Video,1000);
}

void CMP3Dlg::OnToolsRepeat()  // On open Play list
{
	// TODO: Add your command handler code here
	
//	lst.DoModal();
 lst = new playlist1();
   //Check if new succeeded and we got a valid pointer to a dialog object
   if(lst!= NULL)
   {
      BOOL ret = lst->Create(IDD_DIALOG1,this);
      if(!ret)   //Create failed.
         AfxMessageBox("Play List is Currently not Availeble");
      lst->ShowWindow(SW_SHOW);
   }
   else
      AfxMessageBox("Play List is Currently not Availeble");
  
}

void CMP3Dlg::CreateWindowplay(CString str)
{
		if(m_Video!=NULL)
			OnFileClose();
		m_Path=str;
		MCIWndRegisterClass();
		KillTimer(0);
		SetTimer(0,1000,NULL);
		m_Path=str;
		if(m_Video == NULL &&flag==0)
		{
		m_Video =MCIWndCreate(m_screen.GetSafeHwnd(),AfxGetInstanceHandle(),MCIWNDF_NOOPEN|MCIWNDF_NOPLAYBAR |MCIWNDF_NOMENU,m_Path);
		::ShowWindow(m_Video,SW_MAXIMIZE);
		}
		m_SVolume.SetRange( 0, 1000, TRUE );
		m_SVolume.SetPos(500);
		m_mute.SetCheck(1);
		ptr=FromHandle(m_Video);		 
		ptr->UpdateWindow();
	
		MCIWndSetTimeFormat(m_Video ,"ms");
		m_length=MCIWndGetLength(m_Video );
		TotalTime=m_length/1000;
		TotalTime=TotalTime/100;
		m_Seek.SetRange( 0, m_length, TRUE );
		m_Seek.SetPos(0);
		MCIWndPlay(m_Video);
		flag=1;
		UpdateData(FALSE);
		MCIWndSetVolume(m_Video, m_Volume);
		e=0;  // Check for previus created window
}



void CMP3Dlg::OnToolsVolumeUp() 
{
	// TODO: Add your command handler code here
		if(m_mute.GetCheck()==1)
		{
	t=t+10;
	if(t>100)
		t=100;
	MCIWndSetVolume(m_Video, t*10 );
		}
}

void CMP3Dlg::OnToolsVolumeMute() 
{
	// TODO: Add your command handler code here
		if(m_mute.GetCheck()==1){
	MCIWndSetVolume(m_Video, 0 );
	mute=1;
	m_mute.SetCheck(0);
	}
	else
	{
		MCIWndSetVolume(m_Video, t*10 );
		mute=0;
		m_mute.SetCheck(1);
	}
}

void CMP3Dlg::OnToolsVolumeDown() 
{
	// TODO: Add your command handler code here
	if(m_mute.GetCheck()==1)
	{
	if(t<0)
    t=0;	
	MCIWndSetVolume(m_Video, t*10 );
//	SetSlider(t);
	}
}

void CMP3Dlg::SetSlider(int y)
{
	CSliderCtrl   lt;//=CSliderCtrl();
	lt.SetPos(y);
	
}


CString CMP3Dlg::SetExtention(CString  str)
{
	
	int r,t;
	char c;
	CFile classFile;
	CString OldFile, NewFile;

	OldFile.Format("%s", str);
	NewFile.Format("%s", str);

	r=NewFile.GetLength();
	t=r-4;
	c=NewFile.GetAt(t);
	if(c=='.')
	{
		NewFile.SetAt(t+1,'m');
		NewFile.SetAt(t+2,'p');
		NewFile.SetAt(t+3,'g');
		NewFile.Delete(t+4,1);
	}
	classFile.Rename(OldFile, NewFile);
	fFile =TRUE;
	return NewFile;
}

int CMP3Dlg::RestoreExtention(CString str)
{
	if(fFile == true )
	{
		CFile classFile;
		CString OldFile;

		OldFile.Format("%s", str);
	/*	if(OldFileName2!=NULL)
		classFile.Rename(str, OldFileName2);
		else*/
		classFile.Rename(str, m_Path);
	}

	return 0;
}

void CMP3Dlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	OnFileClose();
	MessageBox(" WHY ? ","Security",MB_OK);
	CDialog::OnClose();
}

BOOL CMP3Dlg::OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pLResult) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(lParam == MCI_MODE_PLAY)
		AfxMessageBox("Child Notify");

	return CDialog::OnChildNotify(message, wParam, lParam, pLResult);
}

BOOL CMP3Dlg::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	// TODO: Add your specialized code here and/or call the base class
	char buff[100];
	long vMode;
	vMode = MCIWndGetMode(m_Video, buff, 100);
	if(lParam == MCI_MODE_PLAY)
		AfxMessageBox("Notify");

	return CDialog::OnNotify(wParam, lParam, pResult);
}

void CMP3Dlg::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	AfxMessageBox("Char");
	CDialog::OnChar(nChar, nRepCnt, nFlags);
}

void CMP3Dlg::OnRepeat() 
{
	// TODO: Add your command handler code here
	if(repeat==0)
	repeat=1;
	else
		repeat=0;
}

void CMP3Dlg::OnFileEject() 
{
	// TODO: Add your command handler code here
//	CdOpen(1, GetDrive());
	mciSendString("set cdaudio door open",NULL,NULL,NULL);
}

void CMP3Dlg::OnFileInsert() 
{
	// TODO: Add your command handler code here
//	CdOpen(0 ,GetDrive());
		mciSendString("set cdaudio door closed",NULL,NULL,NULL);
}

void CMP3Dlg::CdOpen(bool open, TCHAR DriveLetter)
{
MCI_OPEN_PARMS op;
	MCI_STATUS_PARMS st;
	DWORD flags;

	TCHAR szDriveName[4];
	strcpy(szDriveName, "X:");

	::ZeroMemory(&op, sizeof(MCI_OPEN_PARMS));
	op.lpstrDeviceType = (LPCSTR) MCI_DEVTYPE_CD_AUDIO;
	
	if (DriveLetter > 1)
	{
		szDriveName[0] = DriveLetter;
		op.lpstrElementName = szDriveName;
		//	set the flags for the device type
		flags = MCI_OPEN_TYPE | MCI_OPEN_TYPE_ID | MCI_OPEN_ELEMENT | MCI_OPEN_SHAREABLE;
	}
	else 
	{
		//	set the flags for the device type
		flags = MCI_OPEN_TYPE | MCI_OPEN_TYPE_ID | MCI_OPEN_SHAREABLE;
	}

	if (!mciSendCommand(0,MCI_OPEN,flags,(unsigned long)&op)) 
	{
		st.dwItem = MCI_STATUS_READY;

		if(open)	//	decides whether to open or close
		{
			//	open drive
			mciSendCommand(op.wDeviceID,MCI_SET,MCI_SET_DOOR_OPEN,0);
		}
		else
		{
			//	close drive
			mciSendCommand(op.wDeviceID,MCI_SET,MCI_SET_DOOR_CLOSED,0);
		}

		//	release access to the device
		mciSendCommand(op.wDeviceID,MCI_CLOSE,MCI_WAIT,0);
	}
}

char CMP3Dlg::GetDrive()
{
	int  drive, curdrive,cd;
	static char path[_MAX_PATH];
	char d;
	CString dir="";
	UINT p=0;
   /* Save current drive. */
   curdrive = _getdrive();

  

   /* If we can switch to the drive, it exists. */
   for( drive = 2; drive <= 26; drive++ )
      if( !_chdrive( drive ) )
			cd=drive + 'A' ;
//printf( "\n Your Current CD drive letter is ");
	d=( "%c: ", cd);
	dir=d;
	p=GetDriveType(dir);
	p=p;
	if(p==DRIVE_CDROM)
	p=p;
//	else
	//	d--;
   /* Restore original drive.*/
   _chdrive( curdrive );
   return d;
}

void CMP3Dlg::OnFileExit() 
{
	// TODO: Add your command handler code here
	OnOK();
}

void CMP3Dlg::OnAboutAboutmediaplayer() 
{
	// TODO: Add your command handler code here
	Aboute g;
	g.DoModal();
}

void CMP3Dlg::OnToolsVolumeAdvanced() 
{
	// TODO: Add your command handler code here
	WinExec("sndvol32.exe", SW_SHOW);
}

void CMP3Dlg::CheckTime(LPVOID param)
{

}

void CMP3Dlg::OnCustomdrawVolume(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	if(m_mute.GetCheck()==1){
	
//	t=reinterpret_cast<CSliderCtrl *>(pScrollBar)->GetPos();
	m_Volume=m_SVolume.GetPos( );
	m_Volume=1000-m_Volume;
	if(m_Volume>1000)
		m_Volume=1000;
	if(m_Volume<0)
		m_Volume=0;
	if(m_Volume<=1000 &&m_Volume>=0)
	MCIWndSetVolume(m_Video, m_Volume);
	else
		AfxMessageBox("Volme can't be changed ");
	//m_Volume=m_SVolume.GetPos();
	}
	*pResult = 0;
}

void CMP3Dlg::OnCustomdrawSlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
/*	MCIWndPause(m_Video);
	int a=m_Seek.GetPos();
	MCIWndSeek(m_Video,a);
	m_Seek.SetPos(a);	
	//m_slider.SetPos(a);
	
	SeekPos=a;
	MCIWndStep(m_Video,a);
  
	MCIWndPlay(m_Video);
	*/
	*pResult = 0;
}

void CMP3Dlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	SeekPos=MCIWndGetPosition(m_Video);
	
	if(flag==1)
	{
	timer++;
	
	m_l=timer/100;
	UpdateData(FALSE);
	}
	
	
	m_Seek.SetPos(SeekPos);

	if(SeekPos==m_length && repeat==1)
	{
		flag=0;	
		OnPlayNext();
			if(FullScreen==1)
			Onfullscreen() ;
		
	}

	
	CDialog::OnTimer(nIDEvent);
}

void CMP3Dlg::OnPlayNext() 
{
	// TODO: Add your command handler code here
	OnFileClose() ;
	SongNo++;
	if(Files[SongNo]!="" )
	{
		CreateWindowplay(Files[SongNo]);
		MCIWndPlay(m_Video);
		flag=1;
	}
	else  
		if(Index==0)
		OnOpen();
	else 
	{
		SongNo=0;
	OnPlayPrevius() ;
	}
}

void CMP3Dlg::OnPlayPrevius() 
{
	// TODO: Add your command handler code here
	OnFileClose() ;
	if(SongNo>0)
	SongNo--;
	if(Files[SongNo]!="")
	{
		CreateWindowplay(Files[SongNo]);
		OnPlay();
	}
	else if(SongNo>Index || SongNo <0)
	{
		SongNo=0;
		OnPlayPrevius() ;
	}
	else
	{
		OnOpen();
	}
}

void CMP3Dlg::OnReleasedcaptureSlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	MCIWndPause(m_Video);
	int a=m_Seek.GetPos();
	MCIWndSeek(m_Video,a);
	m_Seek.SetPos(a);	
	//m_slider.SetPos(a);
	double t;
	t=MCIWndGetPosition(m_Video);;
	t=t/1000;
	//t=t/100;
	timer=t;
	SeekPos=a;
	//MCIWndStep(m_Video,a);
  if( flag==1)
	MCIWndPlay(m_Video);
	*pResult = 0;
	if(m_Video==NULL)
		m_Seek.SetPos(0);
}

void CMP3Dlg::OnViewFullscreen() 
{
	// TODO: Add your command handler code here
	FullScreen=1;
	KillTimer(0);
	MCIWndDestroy(m_Video);
	FS.SeekPos=SeekPos;
	FS.m_Volume=m_Volume;
	FS.m_Path=m_Path;
	FS.DoModal();
	SeekPos=FS.SeekPos;
	if(SeekPos==m_length )
	{
		if( repeat==1)	
		{
			OnPlayNext();
			Onfullscreen() ;
		}
		else
		{
			OnFileClose();
		}
		
	}
	else
	{
		SetTimer(0,1000,NULL);
		
		flag=1;
		m_Video=MCIWndCreate(m_screen.GetSafeHwnd(),AfxGetInstanceHandle(),MCIWNDF_NOOPEN|MCIWNDF_NOPLAYBAR|MCIWNDF_NOMENU ,m_Path);
		::ShowWindow(m_Video,SW_MAXIMIZE);
		MCIWndSetVolume(m_Video,m_Volume);
		MCIWndSetTimeFormat(m_Video ,"ms");
		MCIWndSetActiveTimer(m_Video,500);
        ptr=FromHandle(m_Video);
		m_length=MCIWndGetLength(m_Video);        
		m_Seek.SetRange(0,m_length,TRUE);
		MCIWndPlay(m_Video);
		flag=1;
	    MCIWndSeek(m_Video,SeekPos);
	    MCIWndPlay(m_Video);
		FullScreen=0;
		ptr->UpdateWindow();
}
}

void CMP3Dlg::OnPause() 
{
	// TODO: Add your control notification handler code here
	Onpause();
}

void CMP3Dlg::OnEject() 
{
	// TODO: Add your control notification handler code here
	if(m1==0)
	{
		OnFileEject() ;
		m1=1;
	}
	else
	{
		OnFileInsert() ;
		m1=0;
	}
}

void CMP3Dlg::Onfullscreen() 
{
	// TODO: Add your control notification handler code here
	OnViewFullscreen();
}

void CMP3Dlg::OnPrevius() 
{
	// TODO: Add your control notification handler code here
	OnPlayPrevius() ;
}

void CMP3Dlg::OnNext() 
{
	// TODO: Add your control notification handler code here
	OnPlayNext() ;
}

void CMP3Dlg::OnPlayList() 
{
	// TODO: Add your control notification handler code here
	OnToolsRepeat();
}

void CMP3Dlg::OnSpeedIncrease() 
{
	// TODO: Add your control notification handler code here
	OnToolsSpeedIncrease() ;
}

void CMP3Dlg::OnSpeedSlow() 
{
	// TODO: Add your control notification handler code here
	OnToolsSpeedDecrease() ;
}

void CMP3Dlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	OnOK();
/*	if(!MCIWndRecord(m_Video))
		AfxMessageBox("ASAS");
*/
}

void CMP3Dlg::OnForward() 
{
	// TODO: Add your control notification handler code here
	MCIWndPause(m_Video);
	int a;
	a=MCIWndGetPosition(m_Video);
	a=a+5000;
	if(a<m_length)
	MCIWndSeek(m_Video,a);
	MCIWndPlay(m_Video);
	
}

void CMP3Dlg::OnBack() 
{
	// TODO: Add your control notification handler code here
	MCIWndPause(m_Video);
	int a;
	a=MCIWndGetPosition(m_Video);
	if(m_length>5000 && a<m_length)
	a=a-5000;
	if(a>0)
	MCIWndSeek(m_Video,a);
	MCIWndPlay(m_Video);
}
