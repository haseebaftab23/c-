// playlist.cpp : implementation file
//

#include "stdafx.h"
#include "MP3.h"
#include "playlist.h"
#include "MP3Dlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//#include "MP3Dlg.cpp" 
/////////////////////////////////////////////////////////////////////////////
// playlist dialog


playlist::playlist(CWnd* pParent /*=NULL*/)
	: CDialog(playlist::IDD, pParent)
{
	//{{AFX_DATA_INIT(playlist)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void playlist::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(playlist)
	DDX_Control(pDX, IDC_LIST, m_control);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(playlist, CDialog)
	//{{AFX_MSG_MAP(playlist)
	ON_BN_CLICKED(IDC_Add, OnAdd)
	ON_LBN_DBLCLK(IDC_LIST, OnDblclkList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// playlist message handlers

void playlist::OnAdd() 
{
	// TODO: Add your control notification handler code here
		CFileDialog Avi(TRUE,NULL,NULL,OFN_HIDEREADONLY,"All Files(*.*)|*.*|MP3 Files (*.mp3)|*.mp3|AVI Files(*.avi)|*.avi|");
		if(Avi.DoModal() == IDOK)
		{
			m_Path = Avi.GetPathName();
			m_control.AddString(m_Path);
		
		}
}

void playlist::OnDblclkList() 
{
	// TODO: Add your control notification handler code here
	int index;
	 CString  file;
	// char cFile[100];
	index=m_control.GetCurSel();
	m_control.GetText( index, file );
//	connect(file);
//	CMP3Dlg obj;
//    CreateWindowplay(file);
}
