#if !defined(AFX_PLAYLIST1_H__BB491410_F5FE_4E3D_8ED3_64BCD68C93B7__INCLUDED_)
#define AFX_PLAYLIST1_H__BB491410_F5FE_4E3D_8ED3_64BCD68C93B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// playlist1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// playlist1 dialog

class playlist1 : public CDialog
{
// Construction
public:
	CString OldFileName;
	bool rFlag;
	CString st;
	CString str;
	CString Files[200];
	HWND m_Video;
	int i;
	CRgn m_rgn;
	CString m_Path;
	playlist1(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(playlist1)
	enum { IDD = IDD_DIALOG1 };
	CListBox	m_control;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(playlist1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(playlist1)
	afx_msg void OnDblclkList();
	afx_msg void OnStoredlists();
	afx_msg void OnRemove();
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYLIST1_H__BB491410_F5FE_4E3D_8ED3_64BCD68C93B7__INCLUDED_)
