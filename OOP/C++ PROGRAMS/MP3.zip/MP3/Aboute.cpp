// Aboute.cpp : implementation file
//

#include "stdafx.h"
#include "MP3.h"
#include "Aboute.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Aboute dialog


Aboute::Aboute(CWnd* pParent /*=NULL*/)
	: CDialog(Aboute::IDD, pParent)
{
	//{{AFX_DATA_INIT(Aboute)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Aboute::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Aboute)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Aboute, CDialog)
	//{{AFX_MSG_MAP(Aboute)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Aboute message handlers
