// playlist1.cpp : implementation file
//

#include "stdafx.h"
#include "MP3.h"
#include "playlist1.h"
#include "vfw.h"
#include "MP3Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// playlist1 dialog


playlist1::playlist1(CWnd* pParent /*=NULL*/)
	: CDialog(playlist1::IDD, pParent)
{
	//{{AFX_DATA_INIT(playlist1)
	//}}AFX_DATA_INIT
	rFlag=0;
}


void playlist1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(playlist1)
	DDX_Control(pDX, IDC_LIST, m_control);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(playlist1, CDialog)
	//{{AFX_MSG_MAP(playlist1)
	ON_LBN_DBLCLK(IDC_LIST, OnDblclkList)
	ON_BN_CLICKED(IDC_Storedlists, OnStoredlists)
	ON_BN_CLICKED(IDC_Remove, OnRemove)
	ON_BN_CLICKED(IDC_Add, OnAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL playlist1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CRect r;
	GetClientRect(r);
	m_rgn.CreateEllipticRgn(04,04,r.Width(),r.Height());
	SetWindowRgn(m_rgn,TRUE);
	// TODO: Add extra initialization here
	OnStoredlists();
	SetWindowText( "                                  Play List" );
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
// playlist1 message handlers

void playlist1::OnAdd() 
{
	// TODO: Add your control notification handler code here
	POSITION currPos;
//	int iCheck;

	CFileDialog avi(TRUE,NULL,NULL,OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,"All Files(*.*)|*.*|MP3 Files (*.mp3)|*.mp3|AVI Files(*.avi)|*.avi|");
	if(avi.DoModal() == IDOK)
	{
		currPos = avi.GetStartPosition();
		while(currPos != NULL)
		{
			m_Path = avi.GetNextPathName(currPos);
//			iCheck = CheckFileName(m_Path);

			((CMP3Dlg *)GetParent())->Files[((CMP3Dlg*)GetParent())->m_Index]=m_Path;
			
			m_control.AddString(m_Path);
			((CMP3Dlg*)GetParent())->m_Index=((CMP3Dlg*)GetParent())->m_Index+1;
		//	m_b=((CMP3Dlg*)GetParent())->m_Index;
		//	m_b;
		}
		UpdateData(FALSE);
	}
}

void playlist1::OnDblclkList() 
{
	// TODO: Add your control notification handler code here
	
	i=m_control.GetCurSel();
	m_control.GetText(i,str);
	
	if(((CMP3Dlg*)GetParent())->m_Video!=NULL)
	{
		MCIWndStop(((CMP3Dlg*)GetParent())->m_Video);
		MCIWndDestroy(((CMP3Dlg*)GetParent())->m_Video);
		((CMP3Dlg*)GetParent())->m_Video=NULL;
		((CMP3Dlg*)GetParent())->m_Path=((CMP3Dlg*)GetParent())->OldFileName2;		
	}
	((CMP3Dlg*)GetParent())->NewFileName2=st;
	((CMP3Dlg*)GetParent())->OldFilename=st;
	((CMP3Dlg*)GetParent())->flag=0;
	((CMP3Dlg*)GetParent())->CreateWindowplay(str);
	
	
}

void playlist1::OnStoredlists() 
{
	// TODO: Add your control notification handler code here
	int y=((CMP3Dlg*)GetParent())->m_Index;
//	m_b=y;
		UpdateData(FALSE);
	//	m_control.DeleteString( 0);
		if(y!=0)
	for( i=0;i<=y;i++)
	{
		m_control.InsertString(i, ((CMP3Dlg*)GetParent())->Files[i]);
		
	
	}
	
}

void playlist1::OnRemove() 
{
	// TODO: Add your control notification handler code here
	i=m_control.GetCurSel();
	m_control.DeleteString( i );
	for(int j=0;j<=((CMP3Dlg*)GetParent())->m_Index;j++)
	{
			if(i==j)
			{
			((CMP3Dlg*)GetParent())->Files[i]=((CMP3Dlg*)GetParent())->Files[i+1];
			for(int h=i;h<((CMP3Dlg*)GetParent())->m_Index;h++)
			((CMP3Dlg*)GetParent())->Files[h]=((CMP3Dlg*)GetParent())->Files[h+1];
			}
	}
	((CMP3Dlg*)GetParent())->m_Index--;

}

