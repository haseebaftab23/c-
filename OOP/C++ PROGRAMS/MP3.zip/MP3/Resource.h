//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MP3.rc
//
#define IDD_MP3_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDD_DIALOG1                     131
#define IDD_DIALOG2                     139
#define IDD_DIALOG3                     142
#define IDR_MENU2                       143
#define IDB_BITMAP1                     244
#define IDC_Volume                      1005
#define IDC_EDIT1                       1006
#define IDC_time                        1006
#define IDC_time2                       1007
#define IDC_Mute                        1010
#define IDC_LIST                        1029
#define IDC_Add                         1030
#define IDC_Remove                      1031
#define IDC_Storedlists                 1032
#define IDC_Screen                      1035
#define IDC_SLIDER1                     1037
#define IDC_Play                        1038
#define IDC_Play2                       1039
#define IDC_Play4                       1041
#define IDC_Repeat                      1042
#define IDC_Next                        1043
#define IDC_Previus                     1044
#define IDC_eject                       1045
#define IDC_Back                        1046
#define IDC_Forward                     1047
#define IDC_PlayList                    1050
#define IDC_SpeedIncrease               1051
#define IDC_fullscreen                  1052
#define IDC_SpeedSlow                   1053
#define IDC_Close                       1054
#define IDC_FileClose                   1055
#define ID_Play                         32771
#define ID_Stop                         32772
#define ID_Maximize                     32773
#define ID_Open                         32774
#define ID_pause                        32775
#define ID_CLOSE                        32777
#define ID_Save                         32778
#define ID_Minimize                     32779
#define ID_VIEW__10                     32781
#define ID_VIEW__20                     32782
#define ID_VIEW__40                     32783
#define ID_VIEW_ZOOM_70                 32784
#define ID_VIEW_ZOOM_150                32785
#define ID_TOOLS_SPEED_DOUBLE           32788
#define ID_TOOLS_SPEED_HALF             32789
#define ID_TOOLS_SPEED_INCREASE         32790
#define ID_TOOLS_SPEED_DECREASE         32791
#define ID_TOOLS_SPEED_NORMAL           32792
#define ID_TOOLS_REPEAT                 32793
#define ID_Repeat                       32794
#define ID_TOOLS_VOLUME_UP              32796
#define ID_TOOLS_VOLUME_DOWN            32797
#define ID_TOOLS_VOLUME_MUTE            32798
#define ID_FILE_EJECT                   32799
#define ID_FILE_INSERT                  32800
#define ID_FILE_EXIT                    32801
#define ID_ABOUT_ABOUTMEDIAPLAYER       32802
#define ID_TOOLS_VOLUME_ADVANCED        32803
#define ID_PLAY_NEXT                    32804
#define ID_PLAY_PREVIUS                 32805
#define ID_VIEW_FULLSCREEN              32806
#define ID_MENUITEM32810                32810
#define ID_GH                           32811
#define ID_GHK                          32812

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        245
#define _APS_NEXT_COMMAND_VALUE         32813
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
