#if !defined(AFX_PLAYLIST_H__20F77958_7F36_4C43_9FBA_F29D9639B849__INCLUDED_)
#define AFX_PLAYLIST_H__20F77958_7F36_4C43_9FBA_F29D9639B849__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// playlist.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// playlist dialog



//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYLIST_H__20F77958_7F36_4C43_9FBA_F29D9639B849__INCLUDED_)
