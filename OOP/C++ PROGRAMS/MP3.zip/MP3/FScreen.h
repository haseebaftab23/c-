#if !defined(AFX_FSCREEN_H__5B74C13C_DFEB_4472_99B4_88EABF0AE568__INCLUDED_)
#define AFX_FSCREEN_H__5B74C13C_DFEB_4472_99B4_88EABF0AE568__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FScreen.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FScreen dialog

class FScreen : public CDialog
{
// Construction
public:
	int m_Volume;
	double Length;
	int GetSeek();
	FScreen(CWnd* pParent = NULL);   // standard constructor
	int SeekPos;
	CString m_Path;
	HWND  m_Video;

// Dialog Data
	//{{AFX_DATA(FScreen)
	enum { IDD = IDD_DIALOG3 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FScreen)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(FScreen)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FSCREEN_H__5B74C13C_DFEB_4472_99B4_88EABF0AE568__INCLUDED_)
