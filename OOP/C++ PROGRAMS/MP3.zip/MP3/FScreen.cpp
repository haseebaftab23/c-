// FScreen.cpp : implementation file
//

#include "stdafx.h"
#include "MP3.h"
#include "FScreen.h"

#include "MP3Dlg.h"
#include "vfw.h"
#include "Aboute.h"
#include "windows.h"
#include <ctype.h>
#include <direct.h>

#include <mmsystem.h>
#include "dbt.h"
#include "winuser.h"

#include "playlist1.h"
#include "Digitalv.h"
#include <afxctl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FScreen dialog


FScreen::FScreen(CWnd* pParent /*=NULL*/)
	: CDialog(FScreen::IDD, pParent)
{
	//{{AFX_DATA_INIT(FScreen)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	SeekPos=63;
	m_Path="";
	Length=0;
	m_Volume=15;
	m_Video=NULL;
}


void FScreen::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FScreen)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FScreen, CDialog)
	//{{AFX_MSG_MAP(FScreen)
	ON_WM_TIMER()
	ON_WM_SHOWWINDOW()
	ON_WM_MOUSEMOVE()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FScreen message handlers

int FScreen::GetSeek()
{
return SeekPos;
}

BOOL FScreen::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::DestroyWindow();
}

void FScreen::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	SeekPos=MCIWndGetPosition(m_Video);
	if(SeekPos==Length)
	{
		OnOK();
	}
	CDialog::OnTimer(nIDEvent);
}

void FScreen::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
//	VERIFY(m_bmp1.AutoLoad(IDC_Add,this));
	//VERIFY(m_bmp2.AutoLoad(IDC_Next,this));
	// TODO: Add your message handler code here
	CWnd* desk=GetDesktopWindow();
	//CDC* pdc=desk->GetWindowDC();
	RECT re;
	desk->GetClientRect(&re);
	//::SetWindowPos(this->GetSafeHwnd(),HWND_TOPMOST,re.bottom,re.left,re.right,re.top,SWP_SHOWWINDOW);
		SetTimer(0,1000,NULL);
	::ShowWindow(this->GetSafeHwnd(),SW_MAXIMIZE);
	//SetWindowPos(desk,900,900,900,900,SWP_SHOWWINDOW);
	
		m_Video=MCIWndCreate(this->GetSafeHwnd(),AfxGetInstanceHandle(),MCIWNDF_NOOPEN|MCIWNDF_NOPLAYBAR|MCIWNDF_NOMENU ,m_Path);
	    ::ShowWindow(m_Video,SW_MAXIMIZE); 
		MCIWndSetTimeFormat(m_Video ,"ms");
		MCIWndSetVolume(m_Video, m_Volume);
		MCIWndSetActiveTimer(m_Video,500);
		 MCIWndSeek(m_Video,SeekPos);
	     MCIWndPlay(m_Video);
		 Length=MCIWndGetLength(m_Video);
}

void FScreen::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	CDialog::OnMouseMove(nFlags, point);
}

void FScreen::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	MessageBox(" WHY ? ","Security",MB_OK);
	CDialog::OnClose();
}
