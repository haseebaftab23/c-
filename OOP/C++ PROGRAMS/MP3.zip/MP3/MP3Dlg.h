// MP3Dlg.h : header file
//

#if !defined(AFX_MP3DLG_H__ABDCD8E2_9FBB_43D3_A86E_039D4C0797AC__INCLUDED_)
#define AFX_MP3DLG_H__ABDCD8E2_9FBB_43D3_A86E_039D4C0797AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include"playlist1.h"
#include"FScreen.h"
/////////////////////////////////////////////////////////////////////////////
// CMP3Dlg dialog

class CMP3Dlg : public CDialog
{
// Construction
public:
	bool FullScreen;
	double timer;
	int SongNo;
	int Index;
	LONG Time;
	void CheckTime(LPVOID param);
	CWnd * ptr;
	char GetDrive();
	void CdOpen(bool open, TCHAR DriveLetter);
	CString NewFileName2;
	CString OldFileName2;
	bool fFile;
	CString OldFilename;
	int RestoreExtention(CString str);
	CString SetExtention(CString);
	afx_msg void OnFileClose();
	FScreen  FS;
	CRgn m_rgn;
	//BOOL SetupImages(CImageList *mImageList);
//	void CreateToolBar();
	playlist1 * lst;
	CString Files[200];
	int m_Index;
	CSliderCtrl ctrl;
	void SetSlider(int );
	void CreateWindowplay(CString str);
	void OnHScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar );
	int m_length,m_Volume;
	double m,m1;
	BOOL flag,mute,e ,repeat;
	CString m_Path;
	BOOL Pause;
	int t ,SeekPos;
	HWND m_Video;
	CMP3Dlg(CWnd* pParent = NULL);	// standard constructor
	CToolBarCtrl* m_ToolBar;
	CImageList* m_pImageList;

	CBitmapButton m_bmp1;
	CBitmapButton m_bmp2;
	CBitmapButton m_bmp3;
	CBitmapButton m_bmp4;
	CBitmapButton m_bmp5;
	CBitmapButton m_bmp6;
	CBitmapButton m_bmp7;
	CBitmapButton m_bmp8;
	CBitmapButton m_bmp9;
	CBitmapButton m_bmp10;
	CBitmapButton m_bmp11;
	CBitmapButton m_bmp12;
	CBitmapButton m_bmp13;
	CBitmapButton m_bmp14;
	CBitmapButton m_bmp15;
// Dialog Data
	//{{AFX_DATA(CMP3Dlg)
	enum { IDD = IDD_MP3_DIALOG };
	CSliderCtrl	m_Seek;
	CSliderCtrl	m_SVolume;
	CAnimateCtrl	m_screen;
	CButton	m_slider;
	CButton	m_mute;
	double	m_l;
	double	TotalTime;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMP3Dlg)
	public:
	virtual BOOL OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pLResult);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMP3Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void Onpause();
	afx_msg void OnMute();
	afx_msg void OnOpen();
	afx_msg void OnPlay();
	afx_msg void OnStop();
	afx_msg void OnUpdateOpen(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePlay(CCmdUI* pCmdUI);
	afx_msg void OnMaximize();
	afx_msg void OnSave();
	afx_msg void OnMinimize();
	afx_msg void OnView10();
	afx_msg void OnView20();
	afx_msg void OnView40();
	afx_msg void OnViewZoom70();
	afx_msg void OnViewZoom150();
	afx_msg void OnToolsSpeedDouble();
	afx_msg void OnToolsSpeedHalf();
	afx_msg void OnToolsSpeedIncrease();
	afx_msg void OnToolsSpeedDecrease();
	afx_msg void OnToolsSpeedNormal();
	afx_msg void OnToolsRepeat();
	afx_msg void OnToolsVolumeUp();
	afx_msg void OnToolsVolumeMute();
	afx_msg void OnToolsVolumeDown();
	afx_msg void OnClose();
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnRepeat();
	afx_msg void OnFileEject();
	afx_msg void OnFileInsert();
	afx_msg void OnFileExit();
	afx_msg void OnAboutAboutmediaplayer();
	afx_msg void OnToolsVolumeAdvanced();
	afx_msg void OnCustomdrawVolume(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawSlider1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPlayNext();
	afx_msg void OnPlayPrevius();
	afx_msg void OnReleasedcaptureSlider1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnViewFullscreen();
	afx_msg void OnPause();
	afx_msg void OnEject();
	afx_msg void Onfullscreen();
	afx_msg void OnPrevius();
	afx_msg void OnNext();
	afx_msg void OnPlayList();
	afx_msg void OnSpeedIncrease();
	afx_msg void OnSpeedSlow();
	afx_msg void OnExit();
	afx_msg void OnForward();
	afx_msg void OnBack();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MP3DLG_H__ABDCD8E2_9FBB_43D3_A86E_039D4C0797AC__INCLUDED_)
